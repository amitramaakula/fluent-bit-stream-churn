function names(tag, ts, record)
 local k=record['kubernetes']
 if k == nil or k['pod_name'] == nil then return -1,ts,record end
 local file=string.match(record['source_file'],'([^/]+)$')
 record['destinations']={stable='shared', pod_container=k['pod_name']..'.'..k['container_name'],
  file_only=file, collector_only=os.getenv('POD_NAME'),
  collector_file=os.getenv('POD_NAME')..'.'..file}
 return 1,ts,record
end
